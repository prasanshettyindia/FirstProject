1.import the myAppiumProject as maven project into eclipse editor
2.clean and build the maven project
3.Start the Appium Server and Emulator (Leapdroid emulator was used)
4.Run individual tests as TestNG from src/test/java/com.holmusk.glycoleap.scenarios
5.Can run all tests using runalltests.xml


Note:-
I have made use of TestNG framework, Appium server, Leapdroid emulator, Maven build tool and uiautomator (Android SDK tool) and Eclipse Mars 2.0 editor